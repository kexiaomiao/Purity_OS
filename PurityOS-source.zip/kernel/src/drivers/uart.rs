//! Serial (COM1) output — used as the kernel log / QEMU serial backend.

use spin::Mutex;
use uart_16550::SerialPort;

/// Global COM1 serial port, initialized in [`init`].
static SERIAL: Mutex<SerialPort> = Mutex::new(unsafe { SerialPort::new(0x3F8) });

/// Initialize the serial port. Must be called once early.
pub fn init() {
    SERIAL.lock().init();
}

/// Write a single byte to COM1.
pub fn byte(b: u8) {
    SERIAL.lock().send(b);
}

/// Write a string to COM1.
pub fn write_str(s: &str) {
    let mut serial = SERIAL.lock();
    for b in s.bytes() {
        serial.send(b);
    }
}

#[doc(hidden)]
pub fn _print(args: core::fmt::Arguments) {
    use core::fmt::Write;
    let mut serial = SERIAL.lock();
    let _ = serial.write_fmt(args);
}

/// Kernel logging macro (goes to serial only).
#[macro_export]
macro_rules! klog {
    ($($arg:tt)*) => {
        $crate::drivers::uart::_print(format_args!($($arg)*))
    };
}
